%TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*%
%TF.CreationDate,2026-06-20T16:59:38-04:00*%
%TF.ProjectId,DJ but to separate PCBs,444a2062-7574-4207-946f-207365706172,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-06-20 16:59:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.000000*%
%ADD11C,3.200000*%
%ADD12RoundRect,0.150000X-0.725000X-0.150000X0.725000X-0.150000X0.725000X0.150000X-0.725000X0.150000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,C8*%
X19750000Y-22500000D03*
X19750000Y-27500000D03*
%TD*%
D11*
%TO.C,H11*%
X13750000Y-37000000D03*
%TD*%
%TO.C,H9*%
X13750000Y-13000000D03*
%TD*%
%TO.C,H10*%
X37750000Y-13000000D03*
%TD*%
%TO.C,H12*%
X37750000Y-37000000D03*
%TD*%
D12*
%TO.C,U9*%
X23175000Y-23095000D03*
X23175000Y-24365000D03*
X23175000Y-25635000D03*
X23175000Y-26905000D03*
X28325000Y-26905000D03*
X28325000Y-25635000D03*
X28325000Y-24365000D03*
X28325000Y-23095000D03*
%TD*%
M02*
